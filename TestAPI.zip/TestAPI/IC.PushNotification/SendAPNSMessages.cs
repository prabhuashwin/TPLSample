﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IC.PushNotification
{
    public class SendAPNSMessages
    {
            //var deviceToken = "deviceToken";
            //var payload = new NotificationPayload(deviceToken, "your message", 51); // 51 is the badge no
            //var notificationList = new List<NotificationPayload>() { payload };
            //var push = new PushNotification(true, "aps_developer_identity.p12", "password for the private key");
            //var result = push.SendToApple(notificationList); // You are done!

    }
}
